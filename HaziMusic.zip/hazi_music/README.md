# Hazi Music

Pemutar musik berbasis YouTube dengan login Google. APK dibuild otomatis oleh GitHub Actions.

## Setup Google (sekali saja)
1. Buka Google Cloud Console, buat project baru.
2. APIs & Services > Library > aktifkan **YouTube Data API v3**.
3. OAuth consent screen: pilih External, isi nama app "Hazi Music", tambahkan emailmu di **Test users**.
4. Credentials > Create credentials > **OAuth client ID** > tipe **Android**:
   - Package name: `com.hazi.hazi_music`
   - SHA-1: `48:86:03:FC:CD:9D:5D:03:87:B7:F9:EE:0B:BA:CC:27:14:79:F5:BC`

## Build
Push ke GitHub (branch main). Buka tab **Actions** > pilih run terbaru > unduh artifact **HaziMusic-apk**.
