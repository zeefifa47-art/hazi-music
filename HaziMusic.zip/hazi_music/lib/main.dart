import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:http/http.dart' as http;
import 'package:youtube_player_flutter/youtube_player_flutter.dart';

final googleSignIn = GoogleSignIn(
  scopes: ['email', 'https://www.googleapis.com/auth/youtube.readonly'],
);

void main() => runApp(const HaziMusicApp());

class HaziMusicApp extends StatelessWidget {
  const HaziMusicApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Hazi Music',
        debugShowCheckedModeBanner: false,
        theme: ThemeData.dark(useMaterial3: true).copyWith(
          colorScheme: ColorScheme.fromSeed(
              seedColor: Colors.deepPurple, brightness: Brightness.dark),
        ),
        home: const Root(),
      );
}

class Root extends StatefulWidget {
  const Root({super.key});
  @override
  State<Root> createState() => _RootState();
}

class _RootState extends State<Root> {
  GoogleSignInAccount? _user;
  bool _checking = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    googleSignIn.signInSilently().then((u) {
      if (mounted) setState(() => _user = u);
    }).catchError((_) {}).whenComplete(() {
      if (mounted) setState(() => _checking = false);
    });
  }

  Future<void> _login() async {
    setState(() => _error = null);
    try {
      final u = await googleSignIn.signIn();
      setState(() => _user = u);
    } catch (e) {
      setState(() => _error = 'Login gagal: $e');
    }
  }

  Future<void> _logout() async {
    await googleSignIn.signOut();
    setState(() => _user = null);
  }

  @override
  Widget build(BuildContext context) {
    if (_checking) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    if (_user == null) {
      return Scaffold(
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(32),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.music_note_rounded, size: 96, color: Colors.deepPurpleAccent),
                const SizedBox(height: 12),
                const Text('Hazi Music',
                    style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                const Text('Masuk untuk mulai memutar musik'),
                const SizedBox(height: 32),
                FilledButton.icon(
                  onPressed: _login,
                  icon: const Icon(Icons.login),
                  label: const Text('Masuk dengan Google'),
                ),
                if (_error != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 16),
                    child: Text(_error!,
                        textAlign: TextAlign.center,
                        style: const TextStyle(color: Colors.redAccent)),
                  ),
              ],
            ),
          ),
        ),
      );
    }
    return HomePage(user: _user!, onLogout: _logout);
  }
}

class Song {
  final String id, title, channel, thumb;
  Song(this.id, this.title, this.channel, this.thumb);
}

class HomePage extends StatefulWidget {
  final GoogleSignInAccount user;
  final VoidCallback onLogout;
  const HomePage({super.key, required this.user, required this.onLogout});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final _search = TextEditingController();
  List<Song> _songs = [];
  int _index = -1;
  bool _loading = false;
  String? _error;
  YoutubePlayerController? _ctrl;

  String _clean(String s) => s
      .replaceAll('&amp;', '&')
      .replaceAll('&#39;', "'")
      .replaceAll('&quot;', '"');

  Future<void> _doSearch(String q) async {
    if (q.trim().isEmpty) return;
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final auth = await widget.user.authentication;
      final uri = Uri.https('www.googleapis.com', '/youtube/v3/search', {
        'part': 'snippet',
        'q': q,
        'type': 'video',
        'videoCategoryId': '10',
        'videoEmbeddable': 'true',
        'maxResults': '25',
      });
      final res = await http.get(uri, headers: {
        'Authorization': 'Bearer ${auth.accessToken}',
      });
      final data = jsonDecode(res.body);
      if (res.statusCode != 200) {
        throw data['error']?['message'] ?? 'Gagal mencari';
      }
      final items = (data['items'] as List).map((e) {
        final sn = e['snippet'];
        return Song(
          e['id']['videoId'],
          _clean(sn['title']),
          _clean(sn['channelTitle']),
          sn['thumbnails']['medium']['url'],
        );
      }).toList();
      setState(() => _songs = items);
    } catch (e) {
      setState(() => _error = e.toString());
    } finally {
      setState(() => _loading = false);
    }
  }

  void _play(int i) {
    final song = _songs[i];
    setState(() => _index = i);
    if (_ctrl == null) {
      _ctrl = YoutubePlayerController(
        initialVideoId: song.id,
        flags: const YoutubePlayerFlags(autoPlay: true),
      )..addListener(_onPlayerChange);
    } else {
      _ctrl!.load(song.id);
    }
  }

  void _onPlayerChange() {
    if (_ctrl?.value.playerState == PlayerState.ended &&
        _index + 1 < _songs.length) {
      _play(_index + 1);
    }
  }

  @override
  void dispose() {
    _ctrl?.dispose();
    _search.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final photo = widget.user.photoUrl;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Hazi Music'),
        actions: [
          PopupMenuButton<String>(
            icon: CircleAvatar(
              radius: 14,
              backgroundImage: photo != null ? NetworkImage(photo) : null,
              child: photo == null ? const Icon(Icons.person, size: 16) : null,
            ),
            onSelected: (_) => widget.onLogout(),
            itemBuilder: (_) => [
              PopupMenuItem(enabled: false, child: Text(widget.user.email)),
              const PopupMenuItem(value: 'logout', child: Text('Keluar')),
            ],
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: Column(
        children: [
          if (_ctrl != null)
            YoutubePlayer(controller: _ctrl!, showVideoProgressIndicator: true),
          Padding(
            padding: const EdgeInsets.all(12),
            child: TextField(
              controller: _search,
              textInputAction: TextInputAction.search,
              onSubmitted: _doSearch,
              decoration: InputDecoration(
                hintText: 'Cari lagu atau artis',
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(28)),
              ),
            ),
          ),
          if (_loading) const LinearProgressIndicator(),
          if (_error != null)
            Padding(
              padding: const EdgeInsets.all(12),
              child: Text(_error!,
                  style: const TextStyle(color: Colors.redAccent)),
            ),
          Expanded(
            child: ListView.builder(
              itemCount: _songs.length,
              itemBuilder: (_, i) {
                final s = _songs[i];
                return ListTile(
                  selected: i == _index,
                  leading: ClipRRect(
                    borderRadius: BorderRadius.circular(6),
                    child: Image.network(s.thumb,
                        width: 56, height: 56, fit: BoxFit.cover),
                  ),
                  title: Text(s.title,
                      maxLines: 2, overflow: TextOverflow.ellipsis),
                  subtitle: Text(s.channel,
                      maxLines: 1, overflow: TextOverflow.ellipsis),
                  onTap: () => _play(i),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
